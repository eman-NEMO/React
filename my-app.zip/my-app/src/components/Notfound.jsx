import React from 'react'

export default function Notfound() {
  return (
    <h1>Not found </h1>
  )
}
