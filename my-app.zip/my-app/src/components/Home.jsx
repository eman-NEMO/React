import React from 'react'
import img1 from  "../pictures/avataaars.svg"
export default function Home() {
  return (
    <div className='home '>

       <div className='container'>
           <div className='img'>
           <div> <img src={img1} alt="" className='w-100' width={200} height={200}/></div>
          
           </div>
           <div className='d-flex justify-content-center align-items-center text-center '>
          <div>
          <h1>START FRAMEWORK</h1>
            <p>Graphic Artist - Web Designer - Illustrator</p>
          </div>
           </div>
       </div>
    </div>
  )
}
