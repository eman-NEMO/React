import React from "react";

export default function Contacts() {
  return (
    <div>
     <div className=" contact text-center mt-5"> <h1>CONATCT SECTION</h1></div>
      <form className="w-50 p-3 mx-auto mt-5 mb-4 ng-pristine ng-valid ng-touched ng-submitted">
      
        <input
       
          type="text"
          placeholder="userName"
       
          className="form-control border-0 border-bottom py-3 position-relative ng-pristine ng-valid ng-touched"
        />
      
        <input
        
        
          type="text"
          placeholder="userAge"
     
          className="form-control border-0 border-bottom py-3 position-relative ng-pristine ng-valid ng-touched"
        />
      
      
        <input
         
          type="text"
          placeholder="userEmail"
        
          className="form-control border-0 border-bottom py-3 position-relative ng-pristine ng-valid ng-touched"
        />
      
       
        <input
        
          type="text"
          placeholder="userPassword"
          
          className="form-control border-0 border-bottom py-3 position-relative ng-pristine ng-valid ng-touched"
        />
        <button
         
          className="btn mt-4 text-white"
          style={{ backgroundColor: "#1abc9c" }}
        >
          {" "}
          send Message{" "}
        </button>
      </form>
    </div>
  );
}
