import React from "react";
import img1 from "../pictures/poert1.png";
import img2 from "../pictures/port2.png";
import img3 from "../pictures/port3.png";
import { click } from "@testing-library/user-event/dist/click";
export default function Portfolio() {
  return (


    
    <div className="p">
      <div className="container">
        <div className="row">
          <div className="col-md-4  ">
          <div className=" under ">
          <img src={img1} alt="" className="w-100" />
            <div className="overlay d-flex justify-content-center align-items-center">
              <div className="">
             <i className="text-white fa-solid fa-plus fa-6x"></i>
             </div>
            </div>
          </div>
          </div>
          <div className="col-md-4  ">
          <div className=" under">
          <img src={img2} alt="" className="w-100" />
            <div className="overlay d-flex justify-content-center align-items-center">
             <div className="">
             <i className="text-white fa-solid fa-plus fa-6x"></i>
             </div>
            </div>
          </div>
          </div>
          <div className="col-md-4  ">
          <div className=" under">
          <img src={img3} alt="" className="w-100" />
            <div className="overlay d-flex justify-content-center align-items-center">
             <div className="">
             <i className="text-white fa-solid fa-plus fa-6x"></i>
             </div>
            </div>
          </div>
          </div>
          <div className="col-md-4  ">
          <div className=" under">
          <img src={img1} alt="" className="w-100" />
            <div className="overlay d-flex justify-content-center align-items-center">
             <div className="">
             <i className="text-white fa-solid fa-plus fa-6x"></i>
             </div>
            </div>
          </div>
          </div>
          <div className="col-md-4  ">
          <div className=" under">
          <img src={img2} alt="" className="w-100" />
            <div className="overlay d-flex justify-content-center align-items-center">
             <div className="">
             <i className="text-white fa-solid fa-plus fa-6x"></i>
             </div>
            </div>
          </div>
          </div>
          <div className="col-md-4  ">
          <div className=" under">
          <img src={img3} alt="" className="w-100" />
            <div className="overlay d-flex justify-content-center align-items-center">
             <div className="">
             <i className="text-white fa-solid fa-plus fa-6x"></i>
             </div>
            </div>
          </div>
          </div> 
          
        </div>
      </div>


  
    </div>
  );
}


/**
 * 
 * <div className="fixedimg">
     <div className="item">
      
     </div>
  </div>
 */