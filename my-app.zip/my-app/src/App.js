import React from 'react'
import Layout from'./components/Layout'
import Home from'./components/Home'
import About from'./components/About'
import Portfolio from './components/Portfolio'
import Contacts from'./components/Contacts'
import Notfound from'./components/Notfound'

import { RouterProvider, createBrowserRouter } from 'react-router-dom'

let Routers=createBrowserRouter([
  {path:'',element:<Layout/>,errorElement:<Notfound/>,children:[
    {index:true,element:<Home/>},
    {path:'about',element:<About/>},
    {path:'portfolio',element:<Portfolio/>},
    {path:'contacts',element:<Contacts/>},
    // {path:'*',element:<Notfound/>}
  ]}
])
export default function App() {
  return <RouterProvider router={Routers}>
  </RouterProvider>
}
